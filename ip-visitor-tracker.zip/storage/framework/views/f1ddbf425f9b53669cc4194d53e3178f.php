

<?php $__env->startSection('content'); ?>
<div class="container-fluid py-4">
    <h1 class="mb-4">Blocked IP Address</h1>

    <div class="mb-4">
        <form method="POST" action="<?php echo e(route('ips.block')); ?>" class="row g-3 align-items-center">
            <?php echo csrf_field(); ?>
            <div class="col-auto">
                <input type="text" name="ip_address" class="form-control" placeholder="192.0.2.1" required>
            </div>
            <div class="col-auto">
                <button type="submit" class="btn btn-primary">Add IP Address</button>
            </div>
        </form>
    </div>

    <div class="table-responsive">
        <table class="table table-bordered table-hover align-middle">
            <thead class="table-light">
                <tr>
                    <th>ID</th>
                    <th>IP Address</th>
                    <th>blocked_at</th>
                    <th>Actions</th>
                </tr>
            </thead>
            <tbody>
                <?php $__currentLoopData = $ips; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $ip): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <tr>
                        <td><?php echo e($ip['id']); ?></td>
                        <td class="text-break"><?php echo e($ip['ip_address']); ?></td>
                        <td class="text-break"><?php echo e($ip['blocked_at']); ?></td>
                        <td>
                            <form method="POST" action="<?php echo e(route('ips.unblock')); ?>" class="d-inline">
                                <?php echo csrf_field(); ?>
                                <input type="hidden" name="ip_address" value="<?php echo e($ip['ip_address']); ?>">
                                <button type="submit" class="btn btn-sm btn-outline-danger">Unblock</button>
                            </form>
                        </td>
                    </tr>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </tbody>
        </table>
    </div>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('admin.layouts.app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH D:\wamp64\www\ip-visitor-tracker\resources\views/admin/ips/index.blade.php ENDPATH**/ ?>
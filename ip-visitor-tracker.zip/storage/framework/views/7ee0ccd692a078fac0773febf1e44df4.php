

<?php $__env->startSection('content'); ?>
<div class="row">
    <div class="col-md-4 mb-4">
        <div class="card text-bg-primary">
            <div class="card-body">
                <h5 class="card-title">Total Visitors</h5>
                <p class="card-text fs-4"><?php echo e($totalVisitors ?? 0); ?></p>
                
            </div>
        </div>
    </div>

    <div class="col-md-4 mb-4">
        <div class="card text-bg-danger">
            <div class="card-body">
                <h5 class="card-title">Blocked IPs</h5>
                <p class="card-text fs-4"><?php echo e($blockedIps ?? 0); ?></p>
                
            </div>
        </div>
    </div>

    <div class="col-md-4 mb-4">
        <div class="card text-bg-warning">
            <div class="card-body">
                <h5 class="card-title">Blocked Bots</h5>
                <p class="card-text fs-4"><?php echo e($blockedBots ?? 0); ?></p>
                
            </div>
        </div>
    </div>
</div>

<div class="card mt-4">
    <div class="card-header">
        Latest Visitors
    </div>
    <div class="card-body p-0">
        <table class="table table-striped mb-0">
            <thead>
                <tr>
                    <th>IP Address</th>
                    <th>URL</th>
                    <th>Referrer</th>
                    <th>Location</th>
                    <th>Time</th>
                </tr>
            </thead>
            <tbody>
                <?php $__empty_1 = true; $__currentLoopData = $latestVisitors ?? []; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $log): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                    <tr>
                        <td><?php echo e($log['ip_address']); ?></td>
                        <td><?php echo e($log['visited_url']); ?></td>
                        <td><?php echo e($log['referrer']); ?></td>
                        <td><?php echo e($log['location']); ?></td>
                        <td><?php echo e($log['timestamp']); ?></td>
                    </tr>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                    <tr>
                        <td colspan="5" class="text-center">No visitor data available.</td>
                    </tr>
                <?php endif; ?>
            </tbody>
        </table>
    </div>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('admin.layouts.app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH D:\wamp64\www\ip-visitor-tracker\resources\views/admin/dashboard/index.blade.php ENDPATH**/ ?>
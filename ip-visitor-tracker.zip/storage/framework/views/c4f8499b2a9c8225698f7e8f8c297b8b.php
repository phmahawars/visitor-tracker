

<?php $__env->startSection('content'); ?>
<style>
  tbody tr td, thead tr th{
        white-space: nowrap;

  }
</style>
  
<div class="container-fluid py-4">
    <h1 class="mb-4">Visitor Logs</h1>

    <div class="table-responsive">
        <table id="visitorTable" class="table table-bordered table-hover align-middle">
            <thead class="table-light">
                <tr>
                    <th>ID</th>
                    <th>IP</th>
                    <th>User Agent</th>
                    <th>URL</th>
                    <th>Referrer</th>
                    <th>City</th>
                    <th>State</th>
                    <th>Country</th>
                    <th>Zip</th>
                    <th>Internet Service Provider</th>
                    <th>Organization</th>
                    <th>Autonomous System info</th>
                    <th>Is VPN</th>
                    <th>Blocked?</th>
                    <th>Actions</th>
                </tr>
            </thead>
            <tbody>
            <?php $__currentLoopData = $logs; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $log): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>

                <tr>
                    <td><?php echo e($log->id); ?></td>  <!-- Change from $log['ip_address'] to $log->ip_address -->
                    <td><?php echo e($log->ip_address); ?></td>  <!-- Change from $log['ip_address'] to $log->ip_address -->
                    <td class="text-break"><?php echo e($log->user_agent); ?></td>  <!-- Same change for other fields -->
                    <td class="text-break"><?php echo e($log->visited_url); ?></td>
                    <td class="text-break"><?php echo e($log->referrer); ?></td>
                    <td><?php echo e($log->city); ?></td>
                    <td><?php echo e($log->regionName); ?>, <?php echo e($log->region); ?></td>
                    <td><?php echo e($log->country); ?>, <?php echo e($log->countryCode); ?></td>
                    <td><?php echo e($log->zip); ?></td>
                    <td><?php echo e($log->isp); ?></td>
                    <td><?php echo e($log->org); ?></td>
                    <td><?php echo e($log->as); ?></td>
                    <td>
                      <span class="badge bg-<?php echo e($log->vpn == 1 ? 'danger' : 'success'); ?>">
                            <?php echo e($log->vpn == 1 ? 'Yes' : 'No'); ?>

                        </span>
                    </td>
                    <td>
                        <!-- Display blocked status -->
                        <span class="badge bg-<?php echo e($log->blocked == 'true' ? 'danger' : 'success'); ?>">
                            <?php echo e($log->blocked === 'true' ? 'Yes' : 'No'); ?>

                        </span>
                    </td>
                    <td>
                        <!-- Block or Unblock actions -->
                        <?php if($log->blocked === 'false'): ?>
                            <form method="POST" action="<?php echo e(route('ips.block')); ?>" class="d-inline">
                                <?php echo csrf_field(); ?>
                                <input type="hidden" name="ip_address" value="<?php echo e($log->ip_address); ?>">
                                <button type="submit" class="btn btn-sm btn-outline-danger">Block</button>
                            </form>
                        <?php else: ?>
                            <form method="POST" action="<?php echo e(route('ips.unblock')); ?>" class="d-inline">
                                <?php echo csrf_field(); ?>
                                <input type="hidden" name="ip_address" value="<?php echo e($log->ip_address); ?>">
                                <button type="submit" class="btn btn-sm btn-outline-success">Unblock</button>
                            </form>
                        <?php endif; ?>
                    </td>
                </tr>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </tbody>
        </table>
    </div>

    <?php if($pagination['total_pages'] > 1): ?>
        <nav>
            <ul class="pagination justify-content-center mt-3">
                <?php for($i = 1; $i <= $pagination['total_pages']; $i++): ?>
                    <li class="page-item <?php echo e($i == $pagination['current_page'] ? 'active' : ''); ?>">
                        <a class="page-link" href="<?php echo e(url()->current()); ?>?page=<?php echo e($i); ?>"><?php echo e($i); ?></a>
                    </li>
                <?php endfor; ?>
            </ul>
        </nav>
    <?php endif; ?>
</div>
<script>
    // $(document).ready(function () {
    //     $('#visitorTable').DataTable({
    //         responsive: true,
    //         paging: false,         // 👈 disables pagination
    //         searching: true,
    //         // ordering: true,
    //         info: false,           // 👈 hides "Showing X of Y entries"
    //         language: {
    //             searchPlaceholder: "Search records...",
    //             search: ""
    //         }
    //     });
    // });
</script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('admin.layouts.app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH D:\wamp64\www\ip-visitor-tracker\resources\views/admin/logs/index.blade.php ENDPATH**/ ?>
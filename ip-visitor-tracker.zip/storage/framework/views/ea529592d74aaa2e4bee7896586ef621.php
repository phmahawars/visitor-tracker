

<?php $__env->startSection('content'); ?>
<div class="container-fluid py-4">
    <h1 class="mb-4">Blocked Bots</h1>

    <div class="mb-4">
        <form method="POST" action="<?php echo e(route('bots.block')); ?>" class="row g-3 align-items-center">
            <?php echo csrf_field(); ?>
            <div class="col-auto">
                <input type="text" name="user_agent" class="form-control" placeholder="User Agent" required>
            </div>
            <div class="col-auto">
                <button type="submit" class="btn btn-primary">Add Bot</button>
            </div>
        </form>
    </div>

    <div class="table-responsive">
        <table class="table table-bordered table-hover align-middle">
            <thead class="table-light">
                <tr>
                    <th>ID</th>
                    <th>User Agent</th>
                    <th>Actions</th>
                </tr>
            </thead>
            <tbody>
                <?php $__currentLoopData = $bots; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $bot): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <tr>
                        <td><?php echo e($bot['id']); ?></td>
                        <td class="text-break"><?php echo e($bot['user_agent_pattern']); ?></td>
                        <td>
                            <form method="POST" action="/unblock-bot" class="d-inline">
                                <?php echo csrf_field(); ?>
                                <input type="hidden" name="id" value="<?php echo e($bot['id']); ?>">
                                <button type="submit" class="btn btn-sm btn-outline-danger">Unblock</button>
                            </form>
                        </td>
                    </tr>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </tbody>
        </table>
    </div>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('admin.layouts.app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH D:\wamp64\www\ip-visitor-tracker\resources\views/admin/bots/index.blade.php ENDPATH**/ ?>